package jsf.course.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import jsf.course.entities.OrderForm;
import jsf.course.entities.Movie;

@Stateless
public class OrderFormDAO {
	
	@PersistenceContext
    EntityManager em;
	
	public void insert(OrderForm order) {
		em.persist(order);
	}


	public OrderForm get(Object id) {
		return em.find(OrderForm.class, id);
	}
	
	public List<Movie> getMovies() {
		List<Movie> list = null;

		Query query = em.createQuery("select m from Movie m");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
		
	}
	
	
}
