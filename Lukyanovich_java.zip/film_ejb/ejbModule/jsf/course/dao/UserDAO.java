package jsf.course.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import jsf.course.entities.User;
import jsf.course.entities.Role;

@Stateless
public class UserDAO {

	@PersistenceContext
	EntityManager em;
	
	public void insert(User user) {
		em.persist(user);
	}

	public User update(User user) {
		return em.merge(user);
	}

	public void delete(User user) {
		em.remove(em.merge(user));
	}

	public User get(Object id) {
		return em.find(User.class, id);
	}
	
	

	public boolean checkLogin(String login) {
		
		Query query = em.createQuery("select u from User u where u.logUser=:login");
		query.setParameter("login", login);
		try {
            query.getSingleResult();
            return false;
        }catch (Exception e){
            return true;
        }
		
	}
	
	
	public User getUserFromDatabase(String login, String pass) {
		User u = null;
		Query query = em.createQuery("select u from User u where u.logUser=:login and u.pssUser=:pass");
		query.setParameter("login", login);
		query.setParameter("pass", pass);
		u = (User) query.getSingleResult();
		return u;
	}
	
	public List<String> getUserRolesFromDatabase(User user){
		List<String> r = new ArrayList<String>();
		//List<Role> listRole = null;
		List<Role> listRole = user.getRoles();
		//Query query = em.createQuery("select r from Role r where r.user.idRole=:user");
		//query.setParameter("user", user.idRole);
		
		if (listRole != null) { //save roles in RemoteClient
			for (Role role: listRole) {
				r.add(role.getRoleName());
			}
		}
		return r;
		
	}
	
	
	
	
	public List<User> getFullList() {
		List<User> list = null;

		Query query = em.createQuery("select u from User u");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<User> getList(Map<String, Object> searchParams) {
		List<User> list = null;

		// 1. Build query string with parameters
		String select = "select u ";
		String from = "from User u ";
		String where = "";
		String orderby = "order by u.nameUser asc ";

		// search for name
		String nameUser = (String) searchParams.get("nameUser");
		if (nameUser != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "u.nameUser like :nameUser ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where + orderby);

		// 3. Set configured parameters
		if (nameUser != null) {
			query.setParameter("nameUser", nameUser+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}


}
