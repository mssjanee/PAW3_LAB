package jsf.course.movie;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.simplesecurity.RemoteClient;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import jsf.course.dao.OrderFormDAO;
import jsf.course.entities.OrderForm;
import jsf.course.entities.User;
import jsf.course.dao.UserDAO;
import jsf.course.dao.MovieDAO;
import jsf.course.entities.Movie;
import jsf.course.entities.Role;

@Named
@ViewScoped
public class MakeOrderBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_ORDERS_LIST = "/views/movieListUser?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private OrderForm order = new OrderForm();
	private List<Movie> movie;
	private int idMovie;
	
	

	@EJB
	OrderFormDAO orderformDAO;
	@Inject
	MovieDAO movieDAO;


	@Inject
	FacesContext context;

	@Inject
	Flash flash;
	
	
	@PostConstruct
    public void init() {
        movie=orderformDAO.getMovies();
    }
	
	
	public int getIdMovie() {
		return idMovie;
	}

	public void setIdMovie(int idMovie) {
		this.idMovie = idMovie;
	}

	public List<Movie> getMovie() {
		return movie;
	}

	public void setMovie(List<Movie> movie) {
		this.movie = movie;
	}

	public OrderForm getOrder() {
		return order;
	}

	public void setOrder(OrderForm order) {
		this.order = order;
	}
	
	
	public String makeOrder() {
	 HttpSession session = (HttpSession) FacesContext.getCurrentInstance()
            .getExternalContext().getSession(true);

   User user = (User) RemoteClient.load(session).getDetails();
	 order.setUser(user);
		order.setNbMovOrd(movieDAO.get(idMovie).getNumberMovie());
		orderformDAO.insert(order);
		return PAGE_ORDERS_LIST;
	}
	
	public List<Movie> getAllMovies(){
		return orderformDAO.getMovies();
		
	}
	
	public boolean getAdmin() {
		
		User user = null;
		
		 HttpSession session = (HttpSession) FacesContext.getCurrentInstance()
		            .getExternalContext().getSession(true);
		 try {
		   user = (User) RemoteClient.load(session).getDetails();
		   
		} catch (Exception e) {
			return false;
			
		}
		 
		   List<Role> listRole = user.getRoles();
		   String roleName;
		   
		   if (listRole != null) {
		   for(Role role: listRole){
			   roleName=role.getRoleName();
			   if(roleName=="admin") {
				   return true;
		   }  
			   }
		   }
			   
				   return false;
			  
	}
	
}

