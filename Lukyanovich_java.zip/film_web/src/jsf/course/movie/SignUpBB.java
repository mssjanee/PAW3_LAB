package jsf.course.movie;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.Query;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;


import jsf.course.entities.User;
import jsf.course.dao.UserDAO;


@Named
@RequestScoped
public class SignUpBB {
	private static final String PAGE_MOVIE_MAIN = "/login?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private User user = new User();
		
	@Inject
	ExternalContext extcontext;
	
	@Inject
	Flash flash;
	
	@EJB
	UserDAO userDAO;
	
	@Inject
	FacesContext context;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
	public String signUp() {
		
		if(!userDAO.checkLogin(user.getLogUser())) {
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "User with this login already exists", null));
			return PAGE_STAY_AT_THE_SAME;
		}
		
		userDAO.insert(user);
		return PAGE_MOVIE_MAIN;
		
	}
	
	
}